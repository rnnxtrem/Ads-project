Mini Painel de Link com Ads
----------------------------

index.html       → Painel de visualização dos links
gerar-link.html  → Página para gerar novos links
css/style.css    → Estilos visuais do projeto
js/main.js       → Script para exibir links
js/gerar-link.js → Script para gerar novo link com ads
links.json       → Simula banco de dados de links

Pode ser hospedado no Render.com ou GitHub Pages.
